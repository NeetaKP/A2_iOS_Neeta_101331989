//
//  ViewController.swift
//  LabAssignment-2
//
//  Created by Niko Pant on 2025-03-21.
//

import UIKit

class ViewController: UIViewController {
//    private let button: UIButton = {
    
  

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
                            
    

    


}

